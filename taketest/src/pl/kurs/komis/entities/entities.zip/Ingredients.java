package pl.kurs.komis.entities;

@Entity
public class Ingredients {
	@Id
	private int _ingredient_id;
	private String _name;
	private int _type;
	
	@ManyToOne(fetch=FetchType.EAGER)
	public Dishes _dish;

	public int getIngredient_id() {
		return this._ingredient_id;
	}

	public void setIngredient_id(int aIngredient_id) {
		this._ingredient_id = aIngredient_id;
	}

	public String getName() {
		return this._name;
	}

	public void setName(String aName) {
		this._name = aName;
	}

	public int getType() {
		return this._type;
	}

	public void setType(int aType) {
		this._type = aType;
	}
}