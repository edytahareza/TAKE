package pl.kurs.komis.entities;

import java.util.Vector;

@Entity
public class Orders {
	@Id
	private int _order_id;
	private int _total_cost;
	
	@ManyToOne(fetch=FetchType.EAGER)
	public Clients _client;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,orphanRemoval=true)
	public Vector<Order_position> _order_position = new Vector<Order_position>();

	public int getOrder_id() {
		return this._order_id;
	}

	public void setOrder_id(int aOrder_id) {
		this._order_id = aOrder_id;
	}

	public int getTotal_cost() {
		return this._total_cost;
	}

	public void setTotal_cost(int aTotal_cost) {
		this._total_cost = aTotal_cost;
	}
}