package pl.kurs.komis.entities;

import java.util.Vector;

@Entity
public class Dishes {
	@Id
	private int _dish_id;
	private int _price;
	private String _type;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,orphanRemoval=true)
	public Vector<Order_position> _order_position = new Vector<Order_position>();
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,orphanRemoval=true)
	public Vector<Ingredients> _ingredients = new Vector<Ingredients>();

	public int getDish_id() {
		return this._dish_id;
	}

	public void setDish_id(int aDish_id) {
		this._dish_id = aDish_id;
	}

	public int getPrice() {
		return this._price;
	}

	public void setPrice(int aPrice) {
		this._price = aPrice;
	}

	public String getType() {
		return this._type;
	}

	public void setType(String aType) {
		this._type = aType;
	}
}