package pl.kurs.komis.entities;

import java.util.Vector;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Clients {
	@Id
	private int _client_id;
	private String _name;
	private String _surname;
	private Integer _phone;
	private String _mail;

	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,orphanRemoval=true)
	public Vector<Orders> _orders = new Vector<Orders>();

	public int getClient_id() {
		return this._client_id;
	}

	public void setClient_id(int aClient_id) {
		this._client_id = aClient_id;
	}

	public String getName() {
		return this._name;
	}

	public void setName(String aName) {
		this._name = aName;
	}

	public String getSurname() {
		return this._surname;
	}

	public void setSurname(String aSurname) {
		this._surname = aSurname;
	}

	public Integer getPhone() {
		return this._phone;
	}

	public void setPhone(Integer aPhone) {
		this._phone = aPhone;
	}

	public String getMail() {
		return this._mail;
	}

	public void setMail(String aMail) {
		this._mail = aMail;
	}
}