package pl.kurs.komis.entities;

@Entity
public class Order_position {
	@Id
	private Integer _order_quantity;
	
	@ManyToOne(fetch=FetchType.EAGER)
	public Orders _ordersorder;
	
	@ManyToOne(fetch=FetchType.EAGER)
	public Dishes _dishesdish;

	public Integer getOrder_quantity() {
		return this._order_quantity;
	}

	public void setOrder_quantity(Integer aOrder_quantity) {
		this._order_quantity = aOrder_quantity;
	}
}